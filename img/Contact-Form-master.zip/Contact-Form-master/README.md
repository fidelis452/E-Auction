# Contact-Form
Contact Form in PHP with MYSQL Database ( Client Side + Server Side Validation + Full Responsive )

## Features : -                        
* Full Responsive                          
* Client Side Validation (JQUERY)        
* Server Side Validation (PHP)             
* Supported With All Browsers           
* Easy To Use                           
* Simple & Clean Design                  
* Fully Customizable Validations         

### Used Frameworks :- 
* jquery
* bootstrap
* jQuery Validation Plugin

![contact-form](https://user-images.githubusercontent.com/26626045/58406528-0c4d8e80-8027-11e9-9126-6cb0456431dd.jpg)

## Validation Preview :-

![22222](https://user-images.githubusercontent.com/26626045/58431572-ae8f6580-806b-11e9-85d6-db735fa021ae.PNG)
